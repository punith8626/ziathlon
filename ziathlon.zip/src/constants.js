const CLIENT_STATUS = {
  1: "red",
  2: "green"
};

export default CLIENT_STATUS;

const config = {
  baseURL: `/`
};

export default config;

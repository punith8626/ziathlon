export const formatTime = time => {
  return `${new Date(time).getHours()}  Hours ${new Date(time).getMinutes()}  Minutes`;
};

export const isToday = d => {
  const today = new Date();
  const newDate = new Date(d);
  return (
    newDate.getDate() == today.getDate() &&
    newDate.getMonth() == today.getMonth() &&
    newDate.getFullYear() == today.getFullYear()
  );
};

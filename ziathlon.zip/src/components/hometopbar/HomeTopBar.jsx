import LoginUser from "../loginuser/LoginUser";
import SearchBar from "../searchbar/SearchBar";
import SelectClinic from "../selectclinic/SelectClinic";
const HomeTopBar = () => {
  return (
    <div id="topBar" className="p-2">
      <div id="mainFilter">
        <div className="row">
          <div className="col-4 pe-0">
            <div className="clinicSelect d-flex align-items-center">
              <SelectClinic />
            </div>
          </div>
          <div className="col-md-7 px-0">
            <div className="searchHome mx-2">
              <div className="input-group">
                <SearchBar />
              </div>
            </div>
          </div>
          <div className="col-1 px-0">
            <div className="dropdown loggedInUser">
              <LoginUser />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeTopBar;

import {useEffect, useState} from "react";
import * as service from "../../services/services";
import Calendar from "react-calendar";
import {Button, Alert} from "react-bootstrap";

const BookAppointment = () => {
  const [dateValue, setDateValue] = useState(new Date());
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();
  const [selected, setSelected] = useState("");

  const getTimeSlots = async () => {
    try {
      setLoading(true);
      const response = await service.getSlots();
      if (response?.data) {
        setSlots(response.data);
      }
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  const handleBooking = e => {
    setSelected(e.target.innerHTML);
  };

  const bookAppointment = async () => {
    try {
      setLoading(true);
      const data = {date: dateValue, time: selected};
      await service.bookAppointmentApi(data);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getTimeSlots();
  });

  return (
    <>
      {error && (
        <Alert key="danger" variant="danger">
          {error}
        </Alert>
      )}
      <div className="calender mb-2 text-center d-flex align-items-center justify-content-between">
        <Calendar value={dateValue} onChange={setDateValue} />
      </div>
      <div className="timings mb-2">
        <div className="row">
          <div className="col">
            <h3>FIRST HALF</h3>
            <div className="d-flex justify-content-between align-items-center flex-wrap">
              {(slots.firstHalf || []).map(slot => {
                return (
                  <Button
                    variant={slot.status == "booked" ? "outline-danger" : "outline-secondary"}
                    size="sm"
                    className="activate mb-2"
                    key={`secondoff-${slot.id}`}
                    onClick={handleBooking}
                    disabled={slot.status == "booked" ? true : false}>
                    {slot.name}
                  </Button>
                );
              })}
            </div>
          </div>
          <div className="col">
            <h3>SECOND HALF</h3>
            <div className="d-flex justify-content-between align-items-center flex-wrap">
              {(slots.secondHalf || []).map(slot => {
                return (
                  <Button
                    variant={slot.status == "booked" ? "outline-danger" : "outline-secondary"}
                    size="sm"
                    className="activate mb-2"
                    key={`secondoff-${slot.id}`}
                    onClick={handleBooking}
                    disabled={slot.status == "booked" ? true : false}>
                    {slot.name}
                  </Button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-8">
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder={`Your appointment is at ${selected} on ${dateValue}`}
            />
          </div>
        </div>

        <div className="col-md-4">
          <div className="input-group mb-3">
            <Button
              variant={"primary"}
              className="btn btn-primary aba"
              onClick={bookAppointment}
              disabled={!loading}>
              Confirm
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookAppointment;

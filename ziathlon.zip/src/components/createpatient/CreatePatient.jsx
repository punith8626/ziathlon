import {useState} from "react";
import {Form, InputGroup, Button, Alert} from "react-bootstrap";
import * as service from "../../services/services";

import DatePicker from "react-datepicker";

const initialState = {
  mobileNumber: "",
  name: "",
  dob: "",
  address: "",
  city: "",
  pin: "",
  email: "",
  gender: ""
};
const CreatePatient = () => {
  const [patient, setPatient] = useState(initialState);
  const [startDate, setStartDate] = useState();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();

  const createAbha = () => {};

  const createPatient = async () => {
    try {
      setLoading(true);
      const data = {...patient, dob: new Date(startDate).toString()};
      await service.createPatientApi(data);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };
  const handleChange = e => {
    const key = e.target.name;
    const value = e.target.value;
    setPatient(v => ({
      ...v,
      [key]: value
    }));
  };

  return (
    <>
      {error && (
        <Alert key="danger" variant="danger">
          {error}
        </Alert>
      )}
      <div className="input-group mb-3">
        <Form.Control type="text" placeholder="Enter Client Phone Number" name="mobileNumber" />
      </div>
      <div className="input-group mb-3">
        <Form.Control
          type="text"
          placeholder="Enter Patient Name"
          name="name"
          onChange={handleChange}
        />
      </div>
      <div className="row">
        <div className="col-md-4">
          <InputGroup className="mb-3">
            <InputGroup.Text>#</InputGroup.Text>
            <Form.Control placeholder="Enter UHID" onChange={handleChange} />
          </InputGroup>
        </div>
        <div className="col-md-4 d-flex align-items-center">
          <div className="input-group mb-3 generateUhid">Generate UHID</div>
        </div>
        <div className="col-md-4">
          <InputGroup className="mb-3">
            <DatePicker
              placeholderText="Enter Date of Birth"
              selected={startDate}
              className="form-control"
              onChange={date => setStartDate(date)}
            />
          </InputGroup>
        </div>
      </div>
      <InputGroup className="mb-3">
        <Form.Control placeholder="Age" />
      </InputGroup>
      <div className="form-check form-check-inline">
        <Form.Check
          type={"radio"}
          label={"Female"}
          id={`Female`}
          name="gender"
          onChange={handleChange}
        />
      </div>
      <div className="form-check form-check-inline">
        <Form.Check
          type={"radio"}
          label={"Male"}
          id={`Male`}
          name="gender"
          onChange={handleChange}
        />
      </div>
      <div className="form-check form-check-inline">
        <Form.Check
          type={"radio"}
          label={"Others"}
          id={`Female`}
          name="gender"
          onChange={handleChange}
        />
      </div>
      <div className="row">
        <div className="col-md-6">
          <InputGroup className="mb-3">
            <Form.Control placeholder="Address" name="address" onChange={handleChange} />
          </InputGroup>
        </div>

        <div className="col-md-6">
          <InputGroup className="mb-3">
            <Form.Control placeholder="City" name="city" onChange={handleChange} />
          </InputGroup>
        </div>
      </div>
      <div className="row">
        <div className="col-md-4">
          <InputGroup className="mb-3">
            <Form.Control placeholder="Pincode" name="pin" onChange={handleChange} />
          </InputGroup>
        </div>

        <div className="col-md-8">
          <InputGroup className="mb-3">
            <Form.Control placeholder="Mail Id" name="email" onChange={handleChange} />
          </InputGroup>
        </div>
      </div>
      <div className="row">
        <div className="col-md-4">
          <div className="input-group mb-3">
            <Button variant={"outline-primary"} className="aba" onClick={createAbha}>
              Create ABHA
            </Button>
          </div>
        </div>

        <div className="col-md-8">
          <div className="input-group mb-3">
            <Button variant={"primary"} className="aba" onClick={createPatient} disabled={loading}>
              Add Patient
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreatePatient;

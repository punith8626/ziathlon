import {useState, useEffect} from "react";
import * as service from "../../services/services";
import {Form, Button, Spinner, Alert} from "react-bootstrap";
import {formatTime, isToday} from "../../utils";

const UpcomingAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [filteredAppointments, setfilteredAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState();

  const getAppointmentDetails = async () => {
    try {
      setLoading(true);
      const response = await service.getAppointments();
      if (response?.data?.length) {
        setAppointments(response.data);
        setfilteredAppointments(
          response.data.filter(appointment => {
            if (isToday(appointment.startTime)) {
              return appointment;
            }
          })
        );
      }
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };
  const handleChangeAppointment = e => {
    if (e.target.id === "Tomorrow") {
      setfilteredAppointments(
        appointments.filter(appointment => {
          if (!isToday(appointment.startTime)) {
            return appointment;
          }
        })
      );
    } else {
      setfilteredAppointments(
        appointments.filter(appointment => {
          if (isToday(appointment.startTime)) {
            return appointment;
          }
        })
      );
    }
  };

  useEffect(() => {
    getAppointmentDetails();
  }, []);

  return (
    <div className="card upcomingAppointments">
      <div className="card-header text-center d-flex">
        <Form.Check
          inline
          label="Today"
          name="appointments"
          type={"radio"}
          id="Today"
          onClick={handleChangeAppointment}
        />
        <Form.Check
          inline
          label="Tomorrow"
          name="appointments"
          type={"radio"}
          id="Tomorrow"
          onClick={handleChangeAppointment}
        />
      </div>
      <div className="card-body">
        {loading && (
          <div className="d-flex justify-content-center mb-2">
            <Spinner animation="border" role="status" variant="primary">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
          </div>
        )}
        {error && (
          <Alert key="danger" variant="danger">
            {error}
          </Alert>
        )}
        {filteredAppointments.map(app => {
          return new Date(app.startTime).getTime() > new Date().getTime() ? (
            <div className="user active" key={`appointment-${app.id}`}>
              <p className="name">Name: {app.name}</p>
              <p className="gender">
                {app.gender} | {app.age} <span className="ms-2">{formatTime(app.startTime)}</span>
              </p>
              <div className="d-flex justify-content-between flex-wrap">
                <Button variant="outline-primary" size="sm" className="activate mb-2">
                  Next Dept.
                </Button>
                <Button variant="outline-primary" size="sm" className="activate mb-2">
                  Reschedule
                </Button>
                <Button variant="outline-primary" size="sm" className="activate mb-2">
                  Generate Bill
                </Button>
                <Button variant="outline-primary" size="sm" className="activate mb-2">
                  Check Out
                </Button>
              </div>
            </div>
          ) : (
            <div className="user past" key={`appointment-${app.id}`}>
              <p className="name">Name: {app.name}</p>
              <p className="gender">
                {app.gender} | {app.age} <span className="ms-2">Consultation Over</span>
              </p>

              <Button variant="outline-secondary" size="sm" className="activate mb-2">
                Schedule New Appointment
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default UpcomingAppointments;

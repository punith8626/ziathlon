import { NavLink } from "react-router-dom";

const Navigation = () => {
  return (
    <>
      <nav className="col-md-1 d-none d-md-block sidebar">
        <div className="sidebar-sticky">
          <div className="logo">
            <NavLink
              to="/appointments"
              className={({ isActive }) =>
                isActive ? "nav-link active" : " nav-link"
              }
            >
              Ziathlon <br />
              Logo
            </NavLink>
          </div>

          <ul className="nav flex-column">
            <li className="nav-item">
              <NavLink
                to="/appointments"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Appointments{" "}
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/clients"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Clients
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/departments"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Departments
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/orders"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Orders
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/payments"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Payments
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/analytics"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Analytics
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/abha"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                ABHA
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/tasks"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Tasks
              </NavLink>
            </li>
            
          </ul>
        </div>
      </nav>
    </>
  );
};

export default Navigation;

import  { useContext } from 'react'
import {Form} from "react-bootstrap";
import { ClientsContext } from '../../context/ClientsContext';

const SearchBar = () => {
const {searchClient} = useContext(ClientsContext);
const handleSearch = e => {
    searchClient(e.target.value);
    };
  return (
    <Form.Control
        type="text"
        placeholder="Search by UHID/ABHA/Phone"
        onChange={handleSearch}
    />
  )
}

export default SearchBar
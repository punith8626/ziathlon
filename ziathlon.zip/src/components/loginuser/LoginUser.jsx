import {Dropdown} from "react-bootstrap";

const LoginUser = () => {
  return (
    <Dropdown>
      <Dropdown.Toggle variant="secondary">Logged In User</Dropdown.Toggle>
      <Dropdown.Menu>
        <Dropdown.Item eventKey="1">Signout</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default LoginUser;

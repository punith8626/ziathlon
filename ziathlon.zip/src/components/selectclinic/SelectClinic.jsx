import {useContext} from "react";
import {Form} from "react-bootstrap";
import {GlobalContext} from "../../context/GlobalContext";

const SelectClinic = () => {
  const {clinics} = useContext(GlobalContext);
  return (
    <>
      <Form.Label htmlFor="clinic" className="me-2 mb-0">
        Clinic:
      </Form.Label>
      <Form.Select>
        <option>Select Clinic</option>
        {clinics.length
          ? clinics.map(clinic => {
              return (
                <option key={`clinic-${clinic.id}`} value={clinic.id}>
                  {clinic.title}
                </option>
              );
            })
          : ""}
      </Form.Select>
    </>
  );
};

export default SelectClinic;

import {useContext} from "react";
import {useNavigate, useLocation} from "react-router-dom";

import {Form, Button} from "react-bootstrap";
import {GlobalContext} from "../../context/GlobalContext";
import SelectClinic from "../selectclinic/SelectClinic";
import SearchBar from "../searchbar/SearchBar";
import LoginUser from "../loginuser/LoginUser";

const ClientTopBar = () => {
  const {departments} = useContext(GlobalContext);
  const navigate = useNavigate();
  const location = useLocation();

  const handleSwitchView = res => {
    if (res) {
      navigate("/clients-list");
    } else {
      navigate("/clients");
    }
  };

  return (
    <div id="topBar" className="p-2">
      <div
        className="d-flex align-items-center flex-wrap flex-md-nowrap justify-content-between"
        id="mainFilter">
        <div className="clinicSelect d-flex align-items-center me-2">
          <SelectClinic />
        </div>
        <div className="dashoardViewSwitch">
          <div className="form-check form-switch d-flex p-0 align-items-center">
            <Form.Check
              type="switch"
              id="dashoardView"
              label={location.pathname !== "/clients" ? "Dashboard View" : "List View"}
              onClick={e => {
                handleSwitchView(e.target.checked);
              }}
            />
          </div>
        </div>
        <div className="department">
          <Form.Select>
            <option>Department</option>
            {departments.length
              ? departments.map(department => {
                  return (
                    <option key={`department-${department.id}`} value={department.id}>
                      {department.title}
                    </option>
                  );
                })
              : ""}
          </Form.Select>
        </div>
        <div className="search mx-2">
          <div className="input-group">
            <SearchBar />
          </div>
        </div>
        <div className="addNewClient">
          <Button variant="primary">Add New Client</Button>
        </div>

        <div className="dropdown loggedInUser">
          <LoginUser />
        </div>
      </div>
      <div id="clientInfo" className="mt-2">
        <div className="d-flex align-items-center">
          <div className="clientCount me-2">Clients (440)</div>
          <div className="reference me-2">86 Clients with reference</div>
          <div className="reference me-2">69 Clients with ABHA</div>
          <div className="reference me-2">373 Clients with out ABHA</div>
          <div className="viewAbha">View ABHA Dashboard</div>
        </div>
      </div>
    </div>
  );
};

export default ClientTopBar;

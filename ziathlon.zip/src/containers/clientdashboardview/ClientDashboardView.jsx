import Navigation from "../../components/navigation/Navigation";
import ClientTopBar from "../../components/clienttopbar/ClientTopBar";

const ClientDashboardView = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <Navigation />
        <main className="col-md-11 ml-sm-auto col-lg-11 pt-3 px-4">
          <ClientTopBar />
          <div className="mainContent mt-3">
            <div className="row">
              <div className="col-md-2">
                <div className="card">
                  <div className="card-header">Client Details</div>
                  <div className="card-body">
                    <ul className="list-group list-group-flush">
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client1"
                          />
                          <label className="form-check-label" htmlFor="client1">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client2"
                          />
                          <label className="form-check-label" htmlFor="client2">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client3"
                          />
                          <label className="form-check-label" htmlFor="client3">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client3"
                          />
                          <label className="form-check-label" htmlFor="client3">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client3"
                          />
                          <label className="form-check-label" htmlFor="client3">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>

                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client3"
                          />
                          <label className="form-check-label" htmlFor="client3">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                      <li className="list-group-item p-0 border-0 mb-2">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="client"
                            id="client3"
                          />
                          <label className="form-check-label" htmlFor="client3">
                            <div>
                              <div className="title">Name Lorem Ipsum Lore</div>
                              <div className="age">Male, 48 Years</div>
                              <div className="uhid">
                                UHID Z12345 <span className="px-2"></span>
                                ABHA 9999999999
                              </div>
                            </div>
                          </label>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-3 pe-0 ps-0">
                <div className="card">
                  <div className="card-header">Client Schedule</div>
                  <div className="card-body">
                    <div className="row d-flex align-items-center mb-2">
                      <div className="col pe-0">Sleep Time</div>
                      <div className="col ps-0">
                        <select className="form-select">
                          <option selected>10:00PM</option>
                          <option value="1">10:00PM</option>
                          <option value="2">10:00PM</option>
                          <option value="3">10:00PM</option>
                        </select>
                      </div>
                      <div className="col">
                        <select className="form-select">
                          <option selected>5:00AM</option>
                          <option value="1">10:00PM</option>
                          <option value="2">10:00PM</option>
                          <option value="3">10:00PM</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="accordion accordion-flush" id="accordiondata">
                        <div className="accordion-item border-0 mb-2">
                          <div className="form-check d-flex align-items-center justify-content-between">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              value=""
                              id="one"
                              checked
                            />
                            <label className="form-check-label" htmlFor="one">
                              <div className="d-flex align-items-center justify-content-between">
                                <div className="ps-0 pe-4 timeup">5:00AM</div>
                              </div>
                            </label>
                            <div>
                              <div className="input-group">
                                <input type="text" className="form-control" placeholder="task" />
                              </div>
                            </div>
                          </div>

                          <div
                            id="flush-one"
                            className="accordion-collapse collapse show"
                            data-bs-parent="#accordiondata">
                            <div className="accordion-body p-2">
                              <p className="border-light border-bottom m-0">test</p>
                              <p className="border-light border-bottom m-0">test</p>
                              <p className="border-light border-bottom m-0">test</p>
                              <p className="border-light border-bottom m-0">test</p>
                            </div>
                          </div>
                        </div>
                        <div className="accordion-item border-0 mb-2">
                          <div className="form-check d-flex align-items-center justify-content-between">
                            <input className="form-check-input" type="checkbox" value="" id="two" />
                            <label className="form-check-label" htmlFor="two">
                              <div className="d-flex align-items-center justify-content-between">
                                <div className="ps-0 pe-4 time">6:00AM</div>
                              </div>
                            </label>
                            <div>
                              <div className="input-group">
                                <input type="text" className="form-control" placeholder="task" />
                              </div>
                            </div>
                          </div>

                          <div
                            id="flush-two"
                            className="accordion-collapse collapse"
                            data-bs-parent="#accordiondata">
                            <div className="accordion-body">two</div>
                          </div>
                        </div>
                        <div className="accordion-item border-0 mb-2">
                          <div className="form-check d-flex align-items-center justify-content-between">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              value=""
                              id="three"
                            />
                            <label className="form-check-label" htmlFor="three">
                              <div className="d-flex align-items-center justify-content-between">
                                <div className="ps-0 pe-4 time">7:00AM</div>
                              </div>
                            </label>
                            <div>
                              <div className="input-group">
                                <input type="text" className="form-control" placeholder="task" />
                              </div>
                            </div>
                          </div>

                          <div
                            id="flush-three"
                            className="accordion-collapse collapse"
                            data-bs-parent="#accordiondata">
                            <div className="accordion-body">three</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-7">
                <div className="row">
                  <div className="col-11 pe-0">
                    <div className="card history4Weeks">
                      <div className="card-header">4 Week History of the Cient</div>
                      <div className="card-body p-2">
                        <div className="row">
                          <div className="col d-flex justify-content-between">
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Sun
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Mon
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Tue
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Wed
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Thu
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Fri
                            </button>
                            <button type="button" className="btn btn-primary px-2 py-0 rounded-0">
                              Sat
                            </button>
                          </div>
                          <div className="col d-flex justify-content-between mt-2">
                            <button type="button" className="btn btn-danger rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-warning rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-info rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-light rounded-1">
                              1 Feb
                            </button>
                          </div>
                          <div className="col d-flex justify-content-between mt-2">
                            <button type="button" className="btn btn-danger rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-warning rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-info rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-light rounded-1">
                              1 Feb
                            </button>
                          </div>
                          <div className="col d-flex justify-content-between mt-2">
                            <button type="button" className="btn btn-danger rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-warning rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-info rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-light rounded-1">
                              1 Feb
                            </button>
                          </div>
                          <div className="col d-flex justify-content-between mt-2">
                            <button type="button" className="btn btn-danger rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-success rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-warning rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-info rounded-1">
                              1 Feb
                            </button>
                            <button type="button" className="btn btn-light rounded-1">
                              1 Feb
                            </button>
                          </div>
                        </div>
                        <div className="row" id="historyDetails">
                          <div className="col">
                            <h3 className="my-2">
                              <b>Details of 03 Feb for Client:</b> Name of the client
                            </h3>
                            <div className="row">
                              <div className="col">
                                <table className="table">
                                  <thead>
                                    <tr>
                                      <th scope="col">Time</th>
                                      <th scope="col">Activity</th>
                                      <th scope="col">Status</th>
                                      <th scope="col">%</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <th>5:30 AM</th>
                                      <td>Walking</td>
                                      <td>Done</td>
                                      <td>80%</td>
                                    </tr>
                                    <tr>
                                      <th>5:30 AM</th>
                                      <td>Walking</td>
                                      <td>Done</td>
                                      <td>80%</td>
                                    </tr>
                                    <tr>
                                      <th>5:30 AM</th>
                                      <td>Walking</td>
                                      <td>Done</td>
                                      <td>80%</td>
                                    </tr>
                                    <tr>
                                      <th>5:30 AM</th>
                                      <td>Walking</td>
                                      <td>Done</td>
                                      <td>80%</td>
                                    </tr>
                                    <tr>
                                      <th>5:30 AM</th>
                                      <td>Walking</td>
                                      <td>Done</td>
                                      <td>80%</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              <div className="col activityDetails">
                                <div className="">Activity Details</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-1 pe-0">
                    <div id="historyLaneStart">
                      <div>History Lane</div>
                    </div>
                  </div>
                </div>
              </div>
              {/* <div className="col-md-2 ps-0" id="historyLane">
                <div className="card">
                  <div className="card-header history"> Clients History Lane</div>
                  <div className="card-body p-0">
                    <ul className="list-group list-group-flush">
                      <li className="list-group-item">Apr 26, 1972: Birth</li>
                      <li className="list-group-item">Apr 26, 1972: Birth</li>
                      <li className="list-group-item">Apr 26, 1972: Birth</li>
                    </ul>
                  </div>
                </div>
              </div> */}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ClientDashboardView;

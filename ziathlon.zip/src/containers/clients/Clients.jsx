import Navigation from "../../components/navigation/Navigation";
import ClientTopBar from "../../components/clienttopbar/ClientTopBar";
import {useContext} from "react";
import {ClientsContext} from "../../context/ClientsContext";
import Table from "react-bootstrap/Table";
import CLIENT_STATUS from "../../constants";

const Clients = () => {
  const {clients} = useContext(ClientsContext);

  return (
    <div className="container-fluid">
      <div className="row">
        <Navigation />
        <main className="col-md-11 ml-sm-auto col-lg-11 pt-3 px-4">
          <ClientTopBar />
          <div className="mainContent mt-3">
            <Table className="table" id="clientTable">
              <thead>
                <tr>
                  <th scope="col">Sr. #</th>
                  <th scope="col">Client Details</th>
                  <th scope="col">UHID</th>
                  <th scope="col">ABHA</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Follow Up</th>
                  <th scope="col">Actions</th>
                  <th scope="col">Previous Visit</th>
                  <th scope="col">Cheif Complaints</th>
                </tr>
              </thead>
              <tbody>
                {clients.length > 0
                  ? clients.map(client => {
                    
                      return (
                        <tr key={`clientlist-${client.id}`}>
                          <th>{client.id}</th>
                          <td className={CLIENT_STATUS[client.status]}>{client.description}</td>
                          <td>{client.UHID}</td>
                          <td>{client.ABHA}</td>
                          <td>{client.phone}</td>
                          <td>{client.followUp}</td>
                          <td>{client.actions ? "Start Visit" : ""}</td>
                          <td>{client.previousVisit ? "First Visit" : ""}</td>
                          <td>{client.complaints}</td>
                        </tr>
                      );
                    })
                  : ""}
              </tbody>
            </Table>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Clients;

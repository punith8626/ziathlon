import BookAppointment from "../../components/bookappintment/BookAppointment";
import CreatePatient from "../../components/createpatient/CreatePatient";
import HomeTopBar from "../../components/hometopbar/HomeTopBar";
import Navigation from "../../components/navigation/Navigation";
import UpcomingAppointments from "../../components/upcomingappointments/UpcomingAppointments";

const Home = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <Navigation />
        <main className="col-md-11 ml-sm-auto col-lg-11 pt-3 px-4">
          <HomeTopBar />

          <div className="row" id="mainContentArea">
            <div className="col-10">
              <div className="card createAppointment">
                <div className="card-header text-center">APPOINTMENT SCHEDULER</div>
                <div className="card-body">
                  <div className="row">
                    <div className="col-md-6">
                      <CreatePatient />
                    </div>
                    <div className="col-md-6">
                      <BookAppointment />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-2 ps-0">
              <UpcomingAppointments />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Home;

import api from "../api";
import mocks from "../mocks/mocks";

const mockFetcher = ({
  method,
  url,
  delay = 1000
  // eslint-disable-next-line no-promise-executor-return
}) => new Promise(res => setTimeout(() => res(mocks[`${method}__${url}`]), delay));

const useMocks = true;
const fetch = useMocks ? mockFetcher : api;

export const getClinics = () => fetch({method: "GET", url: "/clinics"});
export const getDepartments = () => fetch({method: "GET", url: "/departments"});
export const getClients = () => fetch({method: "GET", url: "/clients"});
export const getAppointments = () => fetch({method: "GET", url: "/appointments"});
export const getSlots = () => fetch({method: "GET", url: "/appointment/timeslots"});
export const bookAppointmentApi = data =>
  fetch({method: "POST", url: "/appointment/booking", data});

export const createPatientApi = data => fetch({method: "POST", url: "/patient/create", data});

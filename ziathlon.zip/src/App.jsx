import {BrowserRouter, Routes, Route} from "react-router-dom";
import Home from "./containers/home/Home";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-calendar/dist/Calendar.css";
import "react-datepicker/dist/react-datepicker.css";
import "./assets/css/styles.css";
import Clients from "./containers/clients/Clients";
import ClientsProvider from "./context/ClientsContext";
import ClientDashboardView from "./containers/clientdashboardview/ClientDashboardView";

function App() {
  return (
    <div id="ziathlon">
      <ClientsProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />

            <Route path="/clients" element={<Clients />} />
            <Route path="/clients-list" element={<ClientDashboardView />} />

            <Route path="/appointments" element={<Home />} />

            <Route path="/departments" element={<Clients />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </BrowserRouter>
      </ClientsProvider>
    </div>
  );
}

export default App;

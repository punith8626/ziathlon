const mocks = {
  "GET__/clinics": {
    data: [
      {id: 1, title: "Ziathlon - Sports Medicene Clinic"},
      {id: 2, title: "Ziathlon - Ayurveda Medicene Clinic"}
    ]
  },
  "GET__/departments": {
    data: [
      {id: 1, title: "Ayurveda"},
      {id: 2, title: "Alopathy"}
    ]
  },
  "GET__/clients": {
    data: [
      {
        id: 1,
        UHID: "Z12345",
        ABHA: "25487963254875",
        phone: "+91987456321",
        followUp: "Mar 11, 2024 - Mon",
        complaints: "Back Pain",
        description: "Loremm Ipsum Lorem, Male. 27y. 6m",
        actions: true,
        previousVisit: true,
        status: 1
      },
      {
        id: 2,
        UHID: "Z12345",
        ABHA: "25487963254875",
        phone: "+91987456321",
        followUp: "Mar 11, 2024 - Mon",
        complaints: "Back Pain",
        description: "Loremm Ipsum Lorem, Male. 27y. 6m",
        actions: true,
        previousVisit: true,
        status: 2
      },
      {
        id: 3,
        UHID: "Z12345",
        ABHA: "25487963254875",
        phone: "+91987456321",
        followUp: "Mar 11, 2024 - Mon",
        complaints: "Back Pain",
        description: "Loremm Ipsum Lorem, Male. 27y. 6m",
        actions: true,
        previousVisit: true,
        status: 3
      },
      {
        id: 4,
        UHID: "Z12345",
        ABHA: "25487963254875",
        phone: "+91987456321",
        followUp: "Mar 11, 2024 - Mon",
        complaints: "Back Pain",
        description: "Loremm Ipsum Lorem, Male. 27y. 6m",
        actions: true,
        previousVisit: true,
        status: 3
      }
    ]
  },
  "GET__/appointments": {
    data: [
      {
        id: 1,
        name: "Harish TR",
        gender: "Male",
        age: 40,
        startTime: "2024-04-24T09:53:09.949Z"
      },
      {
        id: 2,
        name: "Harish 1",
        gender: "Male",
        age: 30,
        startTime: "2024-04-25T09:53:09.949Z"
      },
      {
        id: 3,
        name: "Harish 2",
        gender: "Male",
        age: 34,
        startTime: "2024-04-25T19:53:09.949Z"
      }
    ]
  },
  "GET__/appointment/timeslots": {
    data: {
      firstHalf: [
        {
          id: 1,
          name: "9.00AM",
          status: "available"
        },
        {
          id: 2,
          name: "9.15AM",
          status: "available"
        },
        {
          id: 3,
          name: "9.30AM",
          status: "available"
        },
        {
          id: 4,
          name: "9.30AM",
          status: "booked"
        }
      ],
      secondHalf: [
        {
          id: 1,
          name: "4.00PM",
          status: "available"
        },
        {
          id: 2,
          name: "4.15PM",
          status: "available"
        },
        {
          id: 3,
          name: "4.30PM",
          status: "available"
        },
        {
          id: 4,
          name: "4.45AM",
          status: "booked"
        }
      ]
    }
  }
};

export default mocks;

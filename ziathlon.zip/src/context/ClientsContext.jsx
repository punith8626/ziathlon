import {useState, useEffect, createContext} from "react";
import * as service from "../services/services";
import PropTypes from "prop-types";


export const ClientsContext = createContext([]);

const ClientsProvider = ({children}) => {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState([]);

  const getClientsDetails = async () => {
    try {
      setLoading(true);
      const response = await service.getClients();
      setClients(response.data);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  const searchClient = (searchText) =>{
    setClients(clients.filter((client)=>{client.abha === searchText || client.uhid === searchText || client.phone === searchText}))
  }

  useEffect(() => {
    getClientsDetails();
  });


  const contextData = {
    error,
    loading,
    clients,
    searchClient
  };

  return <ClientsContext.Provider value={contextData}>{children}</ClientsContext.Provider>;
};

ClientsProvider.propTypes = {
  children: PropTypes.node.isRequired
};

export default ClientsProvider;

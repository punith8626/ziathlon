import {useState, useEffect, createContext} from "react";
import * as service from "../services/services";
import PropTypes from "prop-types";
// import CONSTANTS from "../constants";

export const GlobalContext = createContext([]);

const GlobalProvider = ({children}) => {
  const [clinics, setClinics] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState([]);

  const getClinicDetails = async () => {
    try {
      setLoading(true);
      const response = await service.getClinics();
      setClinics(response.data);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };
  const getDepartmentDetails = async () => {
    try {
      setLoading(true);
      const response = await service.getDepartments();
      setDepartments(response.data);
    } catch (error) {
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getClinicDetails();
    getDepartmentDetails();
  },[]);

  const contextData = {
    error,
    loading,
    clinics,
    departments
  };

  return <GlobalContext.Provider value={contextData}>{children}</GlobalContext.Provider>;
};

GlobalProvider.propTypes = {
  children: PropTypes.node.isRequired
};

export default GlobalProvider;
